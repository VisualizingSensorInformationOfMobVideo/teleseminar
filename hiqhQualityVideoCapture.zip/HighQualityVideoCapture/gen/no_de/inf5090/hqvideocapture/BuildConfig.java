/** Automatically generated file. DO NOT MODIFY */
package no_de.inf5090.hqvideocapture;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}