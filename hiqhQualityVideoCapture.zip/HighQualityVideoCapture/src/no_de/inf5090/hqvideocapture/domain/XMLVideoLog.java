package no_de.inf5090.hqvideocapture.domain;

public class XMLVideoLog {
	
}
